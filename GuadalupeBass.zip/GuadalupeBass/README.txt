GUADALUPE BASS - plugin VST3 pour FL Studio 24

BUILD (Windows, 5 min) :
1. Installe Visual Studio 2022 (charge de travail "Developpement Desktop C++") + CMake + Git
2. Ouvre "x64 Native Tools Command Prompt for VS 2022" dans ce dossier :
     cmake -B build -G "Visual Studio 17 2022"
     cmake --build build --config Release
3. Le .vst3 est copie dans C:\Program Files\Common Files\VST3
   (lance le terminal en administrateur, sinon copie-le a la main depuis build\GuadalupeBass_artefacts\Release\VST3)
4. FL Studio : Options > Manage plugins > "Find installed plugins"
5. Mets-le sur le mixer de ta 808 ou sur le master.

REGLAGES :
- MIX : 0 a 100 % de boost des graves
- FREQ : 1 a 500 Hz, tout ce qui est en dessous est boost (filtre 24 dB/oct)
- Traitement L/R independant = stereo.

AFFICHAGE : deux jauges (L et R) sur les cotes montrent les graves en temps reel (apres boost), avec pic maintenu.

LEFT / RIGHT : deplacent la 808 (panoramique des graves, sans ajouter de volume).
LEFT = la 808 part a gauche, RIGHT = elle part a droite. Les aigus ne bougent pas.
Les deux au meme niveau = elle revient au centre. MIX et FREQ restent independants.

THEMES : le bouton en haut fait defiler 7 themes : Guadalupe, Jungle, Void, Branches, Tiger, Face, Smoke.
Les couleurs des boutons et des jauges sont recalculees automatiquement selon l'image. Le theme choisi est retenu dans le projet FL.

DESIGN : boutons parfaitement ronds, style brutaliste (ombre dure decalee, segments, aiguille epaisse).

AUTOMATION : clic droit sur un bouton (MIX, FREQ, LEFT, RIGHT) ouvre le menu de FL Studio (Create automation clip...).
Si FL n'expose pas ce menu, un menu de secours s'affiche avec la marche a suivre.

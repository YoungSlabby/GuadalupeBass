#include "PluginEditor.h"
#include <BinaryData.h>

namespace
{
    struct ThemeDef { const char* name; const char* data; int size; };

    const ThemeDef kThemes[] = {
        { "Guadalupe", BinaryData::bg_jpeg, BinaryData::bg_jpegSize },
        { "Jungle",    BinaryData::t1_jpg,  BinaryData::t1_jpgSize  },
        { "Void",      BinaryData::t2_jpg,  BinaryData::t2_jpgSize  },
        { "Branches",  BinaryData::t3_jpg,  BinaryData::t3_jpgSize  },
        { "Tiger",     BinaryData::t4_jpg,  BinaryData::t4_jpgSize  },
        { "Face",      BinaryData::t5_jpg,  BinaryData::t5_jpgSize  },
        { "Smoke",     BinaryData::t6_jpg,  BinaryData::t6_jpgSize  },
    };
    constexpr int kNumThemes = (int) (sizeof (kThemes) / sizeof (kThemes[0]));

    Palette goldPalette()
    {
        return { juce::Colour (0xfff2c14e), juce::Colour (0xffb8862b),
                 juce::Colour (0xff2f8a52), juce::Colour (0xff0d2e1a) };
    }

    // Couleurs des boutons calculees automatiquement a partir de l'image
    Palette makePalette (const juce::Image& src)
    {
        if (! src.isValid()) return goldPalette();
        auto img = src.rescaled (48, 64, juce::Graphics::lowResamplingQuality);

        double ar = 0, ag = 0, ab = 0, aw = 0, r = 0, g = 0, b = 0;
        int n = 0;
        for (int y = 0; y < img.getHeight(); ++y)
            for (int x = 0; x < img.getWidth(); ++x)
            {
                auto c = img.getPixelAt (x, y);
                float h, s, v;
                c.getHSB (h, s, v);
                const double w = (double) v * v * (0.25 + s); // favorise les zones claires et colorees
                ar += c.getFloatRed() * w;  ag += c.getFloatGreen() * w;  ab += c.getFloatBlue() * w;  aw += w;
                r += c.getFloatRed();  g += c.getFloatGreen();  b += c.getFloatBlue();  ++n;
            }
        if (aw <= 0.0 || n == 0) return goldPalette();

        float h, s, v;
        juce::Colour::fromFloatRGBA ((float) (ar / aw), (float) (ag / aw), (float) (ab / aw), 1.0f).getHSB (h, s, v);
        const auto accent = juce::Colour::fromHSV (h, juce::jmin (1.0f, s * 1.25f), juce::jmax (v, 0.85f), 1.0f);

        juce::Colour::fromFloatRGBA ((float) (r / n), (float) (g / n), (float) (b / n), 1.0f).getHSB (h, s, v);
        const float cv = juce::jlimit (0.28f, 0.45f, v);
        const float cs = juce::jmin (1.0f, s * 1.3f);
        return { accent, accent.withMultipliedBrightness (0.6f),
                 juce::Colour::fromHSV (h, cs, cv, 1.0f), juce::Colour::fromHSV (h, cs, cv * 0.45f, 1.0f) };
    }
}

void GoldLookAndFeel::drawRotarySlider (juce::Graphics& g, int x, int y, int w, int h, float pos,
                                        float startA, float endA, juce::Slider&)
{
    // style brutaliste : plaque parfaitement ronde, ombre dure decalee, segments, aiguille epaisse
    auto b = juce::Rectangle<float> ((float) x, (float) y, (float) w, (float) h).reduced (8.0f);
    const float r = juce::jmin (b.getWidth(), b.getHeight()) * 0.5f;
    const auto c = b.getCentre();
    const float s = r * 0.74f;
    const float ang = startA + pos * (endA - startA);

    g.setColour (juce::Colours::black.withAlpha (0.55f));
    g.fillEllipse (b);

    // segments (certains manquent ou sont decales)
    for (int i = 0; i < 11; ++i)
    {
        const float t = (float) i / 10.0f;
        const float a = startA + t * (endA - startA);
        const float rad = r - 3.0f;
        juce::Path tk;
        tk.addRectangle (-2.5f, -4.5f, 5.0f, 9.0f);
        tk.applyTransform (juce::AffineTransform::rotation (a).translated (c.x + std::sin (a) * rad, c.y - std::cos (a) * rad));
        const bool lit = t <= pos + 0.001f;
        g.setColour (lit ? pal.accent : juce::Colours::black.withAlpha (0.85f));
        g.fillPath (tk);
        if (! lit) { g.setColour (pal.accentDim); g.strokePath (tk, juce::PathStrokeType (1.0f)); }
    }

    // plaque parfaitement ronde
    const juce::Rectangle<float> disc (c.x - s, c.y - s, s * 2.0f, s * 2.0f);
    g.setColour (juce::Colours::black.withAlpha (0.9f));
    g.fillEllipse (disc.translated (6.0f, 6.0f));                 // ombre dure
    g.setColour (pal.accentDim);
    g.drawEllipse (disc.translated (-4.0f, -4.0f), 1.5f);          // contour decale
    g.setColour (pal.capTop);
    g.fillEllipse (disc);
    g.setColour (pal.accent);
    g.drawEllipse (disc, 3.0f);
    g.setColour (pal.accentDim);
    g.drawEllipse (disc.reduced (s * 0.3f), 1.5f);                 // anneau interieur

    // aiguille epaisse + moyeu carre
    juce::Path bar;
    bar.addRectangle (-3.5f, -s * 0.98f, 7.0f, s * 0.62f);
    bar.applyTransform (juce::AffineTransform::rotation (ang).translated (c.x, c.y));
    g.setColour (juce::Colours::black);
    g.strokePath (bar, juce::PathStrokeType (3.0f));
    g.setColour (pal.accent);
    g.fillPath (bar);
    g.setColour (juce::Colours::black);
    g.fillEllipse (c.x - 5.0f, c.y - 5.0f, 10.0f, 10.0f);
    g.setColour (pal.accent);
    g.drawEllipse (c.x - 5.0f, c.y - 5.0f, 10.0f, 10.0f, 2.0f);
}

void GoldLookAndFeel::drawButtonBackground (juce::Graphics& g, juce::Button& btn, const juce::Colour&,
                                            bool highlighted, bool down)
{
    auto r = btn.getLocalBounds().toFloat().reduced (4.0f);
    const float o = down ? 1.0f : 4.0f;
    g.setColour (pal.accentDim);
    g.fillRect (r.translated (o, o));
    g.setColour (highlighted ? juce::Colours::black : juce::Colours::black.withAlpha (0.92f));
    g.fillRect (r.translated (down ? 2.0f : 0.0f, down ? 2.0f : 0.0f));
    g.setColour (pal.accent);
    g.drawRect (r.translated (down ? 2.0f : 0.0f, down ? 2.0f : 0.0f), 2.0f);
}

GuadalupeBassEditor::GuadalupeBassEditor (GuadalupeBassProcessor& p)
    : AudioProcessorEditor (&p), proc (p), pal (goldPalette())
{
    auto setup = [this] (KnobSlider& s, juce::Label& l, const juce::String& name,
                         const juce::String& suffix, const juce::String& id)
    {
        s.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
        s.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 90, 20);
        s.setTextValueSuffix (suffix);
        s.setLookAndFeel (&laf);
        s.setColour (juce::Slider::textBoxBackgroundColourId, juce::Colours::black.withAlpha (0.7f));
        s.setRotaryParameters (juce::MathConstants<float>::pi * 1.2f,
                               juce::MathConstants<float>::pi * 2.8f, true);
        // clic droit -> menu d'automation de FL Studio
        s.onRightClick = [this, id] (const juce::MouseEvent& e) { openAutomationMenu (id, e.getScreenPosition()); };
        l.setText (name, juce::dontSendNotification);
        l.setJustificationType (juce::Justification::centred);
        l.setFont (juce::FontOptions (16.0f, juce::Font::bold));
        addAndMakeVisible (s);
        addAndMakeVisible (l);
    };
    setup (mixSlider,   mixLabel,   "MIX",   " %",  "mix");
    setup (freqSlider,  freqLabel,  "FREQ",  " Hz", "freq");
    setup (leftSlider,  leftLabel,  "LEFT",  " %",  "left");
    setup (rightSlider, rightLabel, "RIGHT", " %",  "right");

    mixAtt   = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, "mix",   mixSlider);
    freqAtt  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, "freq",  freqSlider);
    leftAtt  = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, "left",  leftSlider);
    rightAtt = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (proc.apvts, "right", rightSlider);

    themeButton.setLookAndFeel (&laf);
    themeButton.setColour (juce::TextButton::buttonColourId, juce::Colours::black.withAlpha (0.75f));
    themeButton.onClick = [this] { setTheme ((themeIndex + 1) % kNumThemes); };
    addAndMakeVisible (themeButton);

    setSize (450, 606); // meme ratio que la photo

    // retrouve le theme choisi lors de la derniere session
    setTheme (juce::jlimit (0, kNumThemes - 1, (int) proc.apvts.state.getProperty ("theme", 0)));

    startTimerHz (30);
}

GuadalupeBassEditor::~GuadalupeBassEditor()
{
    stopTimer();
    themeButton.setLookAndFeel (nullptr);
    for (auto* s : { &mixSlider, &freqSlider, &leftSlider, &rightSlider })
        s->setLookAndFeel (nullptr);
}

void GuadalupeBassEditor::applyPalette (const Palette& p)
{
    pal = p;
    laf.pal = p;
    for (auto* s : { &mixSlider, &freqSlider, &leftSlider, &rightSlider })
    {
        s->setColour (juce::Slider::textBoxTextColourId, p.accent);
        s->setColour (juce::Slider::textBoxOutlineColourId, p.accentDim);
    }
    for (auto* l : { &mixLabel, &freqLabel, &leftLabel, &rightLabel })
        l->setColour (juce::Label::textColourId, p.accent);
    themeButton.setColour (juce::TextButton::textColourOffId, p.accent);
    themeButton.setColour (juce::TextButton::textColourOnId, p.accent);
    repaint();
}

void GuadalupeBassEditor::setTheme (int index)
{
    themeIndex = index;
    const auto& t = kThemes[index];
    bg = juce::ImageFileFormat::loadFrom (t.data, (size_t) t.size);
    applyPalette (index == 0 ? goldPalette() : makePalette (bg));
    proc.apvts.state.setProperty ("theme", index, nullptr);
    themeButton.setButtonText (juce::String ("THEMES  >  ") + t.name);
}

void GuadalupeBassEditor::openAutomationMenu (const juce::String& paramId, juce::Point<int> pos)
{
    auto* param = proc.apvts.getParameter (paramId);
    if (param == nullptr) return;

    // 1) menu natif de FL Studio (Create automation clip, Link to controller...)
    if (auto* ctx = getHostContext())
        if (auto menu = ctx->getContextMenuForParameter (param))
        {
            menu->showNativeMenu (pos);
            return;
        }

    // 2) si l'hote ne propose pas ce menu : menu de secours
    juce::PopupMenu m;
    m.addItem (1, "Valeur par defaut");
    m.addSeparator();
    m.addItem (2, "Automation : liste des parametres du plugin dans FL,", false, false);
    m.addItem (3, "clic droit sur le parametre > Create automation clip", false, false);
    m.showMenuAsync (juce::PopupMenu::Options().withTargetScreenArea (juce::Rectangle<int> (pos.x, pos.y, 1, 1)),
                     [param] (int r)
                     {
                         if (r == 1)
                         {
                             param->beginChangeGesture();
                             param->setValueNotifyingHost (param->getDefaultValue());
                             param->endChangeGesture();
                         }
                     });
}

void GuadalupeBassEditor::timerCallback()
{
    for (int ch = 0; ch < 2; ++ch)
    {
        const float p = proc.bassPeak[ch].exchange (0.0f);
        const float db = juce::Decibels::gainToDecibels (p, -60.0f);
        const float target = juce::jmap (juce::jlimit (-48.0f, 0.0f, db), -48.0f, 0.0f, 0.0f, 1.0f);

        level[ch] = juce::jmax (target, level[ch] * 0.88f);

        if (target >= peakHold[ch]) { peakHold[ch] = target; holdCount[ch] = 20; }
        else if (holdCount[ch] > 0) --holdCount[ch];
        else peakHold[ch] = juce::jmax (0.0f, peakHold[ch] - 0.02f);
    }
    repaint();
}

void GuadalupeBassEditor::drawMeter (juce::Graphics& g, juce::Rectangle<float> r, float lvl, float peak)
{
    g.setColour (pal.accentDim.withAlpha (0.9f));
    g.fillRect (r.expanded (3.0f).translated (3.0f, 3.0f));
    g.setColour (juce::Colours::black.withAlpha (0.85f));
    g.fillRect (r.expanded (3.0f));

    auto fill = r.withTrimmedTop (r.getHeight() * (1.0f - lvl));
    g.setGradientFill (juce::ColourGradient (pal.capTop, r.getX(), r.getBottom(),
                                             pal.accent.brighter (0.3f), r.getX(), r.getY(), false));
    g.fillRect (fill);

    g.setColour (juce::Colours::black.withAlpha (0.8f));
    for (float yy = r.getBottom(); yy > r.getY(); yy -= 7.0f)
        g.fillRect (r.getX(), yy, r.getWidth(), 2.0f);

    g.setColour (juce::Colours::white);
    const float py = r.getBottom() - r.getHeight() * peak;
    g.fillRect (r.getX(), py - 1.0f, r.getWidth(), 2.5f);

    g.setColour (pal.accentDim);
    g.drawRect (r.expanded (3.0f), 2.0f);
}

void GuadalupeBassEditor::paint (juce::Graphics& g)
{
    g.fillAll (juce::Colours::black);
    if (bg.isValid())
        g.drawImage (bg, getLocalBounds().toFloat(), juce::RectanglePlacement::stretchToFit);

    const float top = 70.0f, h = (float) getHeight() - 140.0f, w = 16.0f;
    drawMeter (g, { 10.0f, top, w, h }, level[0], peakHold[0]);
    drawMeter (g, { (float) getWidth() - 10.0f - w, top, w, h }, level[1], peakHold[1]);

    g.setColour (pal.accent);
    g.setFont (juce::FontOptions (12.0f, juce::Font::bold));
    g.drawText ("L", 6, (int) (top + h) + 8, 24, 14, juce::Justification::centred);
    g.drawText ("R", getWidth() - 30, (int) (top + h) + 8, 24, 14, juce::Justification::centred);
}

void GuadalupeBassEditor::resized()
{
    themeButton.setBounds ((getWidth() - 160) / 2, 8, 160, 26);

    const int k = 120;
    mixSlider.setBounds  (38,                       300, k, k + 22);
    freqSlider.setBounds (getWidth() - k - 38,      300, k, k + 22);

    const int s = 92;
    leftSlider.setBounds  (38,                  150, s, s + 22);
    rightSlider.setBounds (getWidth() - s - 38, 150, s, s + 22);
    leftLabel.setBounds  (leftSlider.getX(),  leftSlider.getY() - 22,  s, 20);
    rightLabel.setBounds (rightSlider.getX(), rightSlider.getY() - 22, s, 20);

    mixLabel.setBounds  (mixSlider.getX(),  mixSlider.getY() - 22,  k, 20);
    freqLabel.setBounds (freqSlider.getX(), freqSlider.getY() - 22, k, 20);
}

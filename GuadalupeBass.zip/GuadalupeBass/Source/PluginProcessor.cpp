#include "PluginProcessor.h"
#include "PluginEditor.h"

GuadalupeBassProcessor::GuadalupeBassProcessor()
    : AudioProcessor (BusesProperties()
          .withInput  ("Input",  juce::AudioChannelSet::stereo(), true)
          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMS", createLayout())
{
}

juce::AudioProcessorValueTreeState::ParameterLayout GuadalupeBassProcessor::createLayout()
{
    juce::AudioProcessorValueTreeState::ParameterLayout l;

    l.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "mix", 1 }, "Mix",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 50.0f,
        juce::AudioParameterFloatAttributes().withLabel ("%")));

    // 1 Hz -> 500 Hz, echelle logarithmique (skew) pour bien regler dans les graves
    juce::NormalisableRange<float> fr (1.0f, 500.0f, 0.1f);
    fr.setSkewForCentre (60.0f);
    l.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "freq", 1 }, "Frequence", fr, 60.0f,
        juce::AudioParameterFloatAttributes().withLabel ("Hz")));

    // ecartement de la 808 : bass en plus sur le cote gauche / droit
    l.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "left", 1 }, "Left",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel ("%")));
    l.add (std::make_unique<juce::AudioParameterFloat> (
        juce::ParameterID { "right", 1 }, "Right",
        juce::NormalisableRange<float> (0.0f, 100.0f, 0.1f), 0.0f,
        juce::AudioParameterFloatAttributes().withLabel ("%")));

    return l;
}

void GuadalupeBassProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    sr = sampleRate;
    juce::dsp::ProcessSpec spec { sampleRate, (juce::uint32) samplesPerBlock, 2 };
    for (auto* f : { &lp1, &lp2 })
    {
        f->prepare (spec);
        f->setType (juce::dsp::StateVariableTPTFilterType::lowpass);
        f->reset();
    }
    mixSmooth.reset (sampleRate, 0.03);
    freqSmooth.reset (sampleRate, 0.03);
    sideSmooth[0].reset (sampleRate, 0.03);
    sideSmooth[1].reset (sampleRate, 0.03);
    sideSmooth[0].setCurrentAndTargetValue (*apvts.getRawParameterValue ("left")  / 100.0f);
    sideSmooth[1].setCurrentAndTargetValue (*apvts.getRawParameterValue ("right") / 100.0f);
    mixSmooth.setCurrentAndTargetValue (*apvts.getRawParameterValue ("mix") / 100.0f);
    freqSmooth.setCurrentAndTargetValue (*apvts.getRawParameterValue ("freq"));
}

bool GuadalupeBassProcessor::isBusesLayoutSupported (const BusesLayout& l) const
{
    return l.getMainInputChannelSet() == juce::AudioChannelSet::stereo()
        && l.getMainOutputChannelSet() == juce::AudioChannelSet::stereo();
}

void GuadalupeBassProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    mixSmooth.setTargetValue (*apvts.getRawParameterValue ("mix") / 100.0f);
    freqSmooth.setTargetValue (*apvts.getRawParameterValue ("freq"));
    sideSmooth[0].setTargetValue (*apvts.getRawParameterValue ("left")  / 100.0f);
    sideSmooth[1].setTargetValue (*apvts.getRawParameterValue ("right") / 100.0f);

    if (buffer.getNumChannels() < 2) return;

    const int n = buffer.getNumSamples();
    constexpr float maxBoost = 3.0f; // mix 100% = graves x4 (~ +12 dB)
    constexpr float pi4 = juce::MathConstants<float>::pi * 0.25f;
    float pk[2] { 0.0f, 0.0f };

    auto* d0 = buffer.getWritePointer (0);
    auto* d1 = buffer.getWritePointer (1);

    for (int i = 0; i < n; ++i)
    {
        const float mix = mixSmooth.getNextValue();
        const float f = juce::jlimit (1.0f, 500.0f, freqSmooth.getNextValue());
        lp1.setCutoffFrequency (f);
        lp2.setCutoffFrequency (f);

        const float in[2] { d0[i], d1[i] };

        // bande de graves de chaque canal (L et R traites separement)
        float low[2];
        for (int ch = 0; ch < 2; ++ch)
            low[ch] = lp2.processSample (ch, lp1.processSample (ch, in[ch]));

        // DEPLACEMENT de la 808 : LEFT la pousse a gauche, RIGHT a droite.
        // Panoramique a puissance constante : aucun gain ajoute, le volume ne change pas.
        const float p   = sideSmooth[1].getNextValue() - sideSmooth[0].getNextValue(); // -1 gauche ... +1 droite
        const float amt = std::abs (p);
        const float th  = (p + 1.0f) * pi4;
        const float pg[2] { 1.41421356f * std::cos (th), 1.41421356f * std::sin (th) };
        const float m = 0.5f * (low[0] + low[1]); // graves en mono, replaces ou on veut

        const float g = 1.0f + mix * maxBoost; // bass boost (MIX)

        float* out[2] { d0, d1 };
        for (int ch = 0; ch < 2; ++ch)
        {
            const float placed = low[ch] * (1.0f - amt) + m * pg[ch] * amt;
            out[ch][i] = (in[ch] - low[ch]) + placed * g; // aigus intacts + graves deplaces/boostes
            pk[ch] = juce::jmax (pk[ch], std::abs (placed * g));
        }
    }

    for (int ch = 0; ch < 2; ++ch)
        bassPeak[ch].store (juce::jmax (bassPeak[ch].load(), pk[ch]));
}

juce::AudioProcessorEditor* GuadalupeBassProcessor::createEditor()
{
    return new GuadalupeBassEditor (*this);
}

void GuadalupeBassProcessor::getStateInformation (juce::MemoryBlock& dest)
{
    if (auto xml = apvts.copyState().createXml()) copyXmlToBinary (*xml, dest);
}

void GuadalupeBassProcessor::setStateInformation (const void* data, int size)
{
    if (auto xml = getXmlFromBinary (data, size))
        apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter() { return new GuadalupeBassProcessor(); }

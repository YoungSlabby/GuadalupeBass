#pragma once
#include "PluginProcessor.h"

struct Palette { juce::Colour accent, accentDim, capTop, capBottom; };

class GoldLookAndFeel : public juce::LookAndFeel_V4
{
public:
    Palette pal { juce::Colour (0xfff2c14e), juce::Colour (0xffb8862b), juce::Colour (0xff2f8a52), juce::Colour (0xff0d2e1a) };
    void drawRotarySlider (juce::Graphics&, int x, int y, int w, int h, float pos,
                           float startAngle, float endAngle, juce::Slider&) override;
    void drawButtonBackground (juce::Graphics&, juce::Button&, const juce::Colour&,
                               bool highlighted, bool down) override;
};

// Slider dont le clic droit ouvre le menu d'automation de l'hote (FL Studio)
class KnobSlider : public juce::Slider
{
public:
    std::function<void (const juce::MouseEvent&)> onRightClick;
    void mouseDown (const juce::MouseEvent& e) override
    {
        if (e.mods.isPopupMenu()) { if (onRightClick) onRightClick (e); return; }
        juce::Slider::mouseDown (e);
    }
    void mouseDrag (const juce::MouseEvent& e) override { if (! e.mods.isPopupMenu()) juce::Slider::mouseDrag (e); }
    void mouseUp   (const juce::MouseEvent& e) override { if (! e.mods.isPopupMenu()) juce::Slider::mouseUp (e); }
};

class GuadalupeBassEditor : public juce::AudioProcessorEditor,
                            private juce::Timer
{
public:
    explicit GuadalupeBassEditor (GuadalupeBassProcessor&);
    ~GuadalupeBassEditor() override;
    void paint (juce::Graphics&) override;
    void resized() override;

private:
    void timerCallback() override;
    void drawMeter (juce::Graphics&, juce::Rectangle<float>, float level, float peak);
    void setTheme (int index);
    void applyPalette (const Palette&);
    void openAutomationMenu (const juce::String& paramId, juce::Point<int> screenPos);

    GuadalupeBassProcessor& proc;
    GoldLookAndFeel laf;
    Palette pal;
    juce::Image bg;
    int themeIndex = 0;
    juce::TextButton themeButton;

    KnobSlider mixSlider, freqSlider, leftSlider, rightSlider;
    juce::Label mixLabel, freqLabel, leftLabel, rightLabel;
    std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> mixAtt, freqAtt, leftAtt, rightAtt;

    float level[2] { 0, 0 }, peakHold[2] { 0, 0 };
    int holdCount[2] { 0, 0 };

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (GuadalupeBassEditor)
};

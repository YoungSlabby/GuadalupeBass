#pragma once
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>

class GuadalupeBassProcessor : public juce::AudioProcessor
{
public:
    GuadalupeBassProcessor();
    ~GuadalupeBassProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }
    const juce::String getName() const override { return "Guadalupe Bass"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }
    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}
    void getStateInformation (juce::MemoryBlock&) override;
    void setStateInformation (const void*, int) override;

    juce::AudioProcessorValueTreeState apvts;

    // niveau des graves (L/R) lu par l'affichage, remis a zero a chaque lecture
    std::atomic<float> bassPeak[2] { 0.0f, 0.0f };

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

    juce::dsp::StateVariableTPTFilter<float> lp1, lp2; // 2 en cascade = 24 dB/oct
    juce::SmoothedValue<float> mixSmooth, freqSmooth, sideSmooth[2];
    double sr = 44100.0;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (GuadalupeBassProcessor)
};

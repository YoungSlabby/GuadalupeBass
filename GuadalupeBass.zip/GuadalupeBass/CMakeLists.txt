cmake_minimum_required(VERSION 3.22)
project(GuadalupeBass VERSION 1.0.0)
set(CMAKE_CXX_STANDARD 17)

include(FetchContent)
FetchContent_Declare(JUCE GIT_REPOSITORY https://github.com/juce-framework/JUCE.git GIT_TAG 8.0.4)
FetchContent_MakeAvailable(JUCE)

juce_add_plugin(GuadalupeBass
    COMPANY_NAME "Guadalupe"
    PLUGIN_MANUFACTURER_CODE Guad
    PLUGIN_CODE Gbas
    FORMATS VST3
    PRODUCT_NAME "Guadalupe Bass"
    IS_SYNTH FALSE
    NEEDS_MIDI_INPUT FALSE
    COPY_PLUGIN_AFTER_BUILD TRUE)

juce_add_binary_data(Assets SOURCES assets/bg.jpeg assets/t1.jpg assets/t2.jpg assets/t3.jpg assets/t4.jpg assets/t5.jpg assets/t6.jpg)

target_sources(GuadalupeBass PRIVATE
    Source/PluginProcessor.cpp Source/PluginProcessor.h
    Source/PluginEditor.cpp Source/PluginEditor.h)

target_compile_definitions(GuadalupeBass PUBLIC
    JUCE_WEB_BROWSER=0 JUCE_USE_CURL=0 JUCE_VST3_CAN_REPLACE_VST2=0)

target_link_libraries(GuadalupeBass PRIVATE Assets
    juce::juce_audio_utils juce::juce_dsp
    PUBLIC juce::juce_recommended_config_flags juce::juce_recommended_warning_flags)

if(MSVC)
    target_compile_options(GuadalupeBass PRIVATE /utf-8)
endif()
